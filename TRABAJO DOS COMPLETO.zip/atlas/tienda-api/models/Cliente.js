const mongoose = require('mongoose');

const clienteSchema = new mongoose.Schema({
  nombre: { type: String, required: true },
  email: { type: String, required: true },
  edad: { type: Number, required: true },
  ciudad: { type: String, required: true },
  telefono: String,
  direccion: String
}, { timestamps: true });

module.exports = mongoose.model('Cliente', clienteSchema);