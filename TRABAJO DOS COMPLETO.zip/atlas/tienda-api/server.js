const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const path = require("path");

// Importar modelos
const Cliente = require("./models/Cliente");
const Producto = require("./models/Producto");
const Pedido = require("./models/Pedido");
const Proveedor = require("./models/Proveedor");

const app = express();

// Middlewares
app.use(express.json());
app.use(cors());
app.use(express.static(path.join(__dirname, "public")));

// CONEXIÓN A MONGODB
mongoose.connect("mongodb+srv://janergomez765_db_user:root@cluster0.papnyk8.mongodb.net/tienda_online")
  .then(() => console.log("✅ Conectado a MongoDB Atlas"))
  .catch(err => console.log("❌ Error de conexión:", err));

// RUTA HEALTH
app.get("/api/health", (req, res) => {
  res.json({ ok: true, mensaje: "API funcionando correctamente" });
});

// ============================================
// CRUD CLIENTES
// ============================================

app.get("/api/clientes", async (req, res) => {
  try {
    const { id } = req.query;
    if (id) {
      const cliente = await Cliente.findById(id);
      if (!cliente) return res.status(404).json({ ok: false, mensaje: "Cliente no encontrado" });
      return res.json({ ok: true, data: cliente });
    }
    const clientes = await Cliente.find();
    res.json({ ok: true, data: clientes });
  } catch (error) {
    res.status(400).json({ ok: false, mensaje: error.message });
  }
});

app.post("/api/clientes", async (req, res) => {
  try {
    const nuevoCliente = new Cliente(req.body);
    const resultado = await nuevoCliente.save();
    res.json({ ok: true, data: resultado, mensaje: "Cliente creado" });
  } catch (error) {
    res.status(400).json({ ok: false, mensaje: error.message });
  }
});

app.put("/api/clientes/:id", async (req, res) => {
  try {
    const clienteActualizado = await Cliente.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    if (!clienteActualizado) return res.status(404).json({ ok: false, mensaje: "Cliente no encontrado" });
    res.json({ ok: true, data: clienteActualizado, mensaje: "Cliente actualizado" });
  } catch (error) {
    res.status(400).json({ ok: false, mensaje: error.message });
  }
});

app.delete("/api/clientes/:id", async (req, res) => {
  try {
    const cliente = await Cliente.findByIdAndDelete(req.params.id);
    if (!cliente) return res.status(404).json({ ok: false, mensaje: "Cliente no encontrado" });
    res.json({ ok: true, mensaje: "Cliente eliminado" });
  } catch (error) {
    res.status(400).json({ ok: false, mensaje: error.message });
  }
});

// ============================================
// CRUD PRODUCTOS
// ============================================

app.get("/api/productos", async (req, res) => {
  try {
    const { id } = req.query;
    if (id) {
      const producto = await Producto.findById(id);
      if (!producto) return res.status(404).json({ ok: false, mensaje: "Producto no encontrado" });
      return res.json({ ok: true, data: producto });
    }
    const productos = await Producto.find();
    res.json({ ok: true, data: productos });
  } catch (error) {
    res.status(400).json({ ok: false, mensaje: error.message });
  }
});

app.post("/api/productos", async (req, res) => {
  try {
    const nuevoProducto = new Producto(req.body);
    const resultado = await nuevoProducto.save();
    res.json({ ok: true, data: resultado, mensaje: "Producto creado" });
  } catch (error) {
    res.status(400).json({ ok: false, mensaje: error.message });
  }
});

app.put("/api/productos/:id", async (req, res) => {
  try {
    const productoActualizado = await Producto.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    if (!productoActualizado) return res.status(404).json({ ok: false, mensaje: "Producto no encontrado" });
    res.json({ ok: true, data: productoActualizado, mensaje: "Producto actualizado" });
  } catch (error) {
    res.status(400).json({ ok: false, mensaje: error.message });
  }
});

app.delete("/api/productos/:id", async (req, res) => {
  try {
    const producto = await Producto.findByIdAndDelete(req.params.id);
    if (!producto) return res.status(404).json({ ok: false, mensaje: "Producto no encontrado" });
    res.json({ ok: true, mensaje: "Producto eliminado" });
  } catch (error) {
    res.status(400).json({ ok: false, mensaje: error.message });
  }
});

// ============================================
// CRUD PEDIDOS
// ============================================

app.get("/api/pedidos", async (req, res) => {
  try {
    const pedidos = await Pedido.find().sort({ createdAt: -1 });
    res.json({ ok: true, data: pedidos });
  } catch (error) {
    res.status(400).json({ ok: false, mensaje: error.message });
  }
});

app.post("/api/pedidos", async (req, res) => {
  try {
    const { cliente_id, productos, direccion_entrega } = req.body;
    
    const cliente = await Cliente.findById(cliente_id);
    if (!cliente) {
      return res.status(404).json({ ok: false, mensaje: "Cliente no encontrado" });
    }
    
    let total = 0;
    const productosDetalle = [];
    
    for (const item of productos) {
      const producto = await Producto.findById(item.producto_id);
      if (!producto) {
        return res.status(404).json({ ok: false, mensaje: `Producto no encontrado` });
      }
      
      if (producto.stock < item.cantidad) {
        return res.status(400).json({ ok: false, mensaje: `Stock insuficiente para ${producto.nombre}` });
      }
      
      const subtotal = producto.precio * item.cantidad;
      total += subtotal;
      
      productosDetalle.push({
        producto_id: producto._id,
        cantidad: item.cantidad,
        nombre_producto: producto.nombre,
        precio_unitario: producto.precio
      });
      
      producto.stock -= item.cantidad;
      await producto.save();
    }
    
    const nuevoPedido = new Pedido({
      cliente_id,
      productos: productosDetalle,
      total,
      direccion_entrega,
      nombre_cliente: cliente.nombre,
      estado: "pendiente"
    });
    
    const resultado = await nuevoPedido.save();
    res.json({ ok: true, data: resultado, mensaje: "Pedido creado" });
  } catch (error) {
    res.status(400).json({ ok: false, mensaje: error.message });
  }
});

app.put("/api/pedidos/:id", async (req, res) => {
  try {
    const { estado } = req.body;
    const pedido = await Pedido.findByIdAndUpdate(
      req.params.id,
      { estado },
      { new: true }
    );
    if (!pedido) return res.status(404).json({ ok: false, mensaje: "Pedido no encontrado" });
    res.json({ ok: true, data: pedido, mensaje: "Estado actualizado" });
  } catch (error) {
    res.status(400).json({ ok: false, mensaje: error.message });
  }
});

app.delete("/api/pedidos/:id", async (req, res) => {
  try {
    const pedido = await Pedido.findByIdAndDelete(req.params.id);
    if (!pedido) return res.status(404).json({ ok: false, mensaje: "Pedido no encontrado" });
    res.json({ ok: true, mensaje: "Pedido eliminado" });
  } catch (error) {
    res.status(400).json({ ok: false, mensaje: error.message });
  }
});

// ============================================
// CRUD PROVEEDORES
// ============================================

app.get("/api/proveedores", async (req, res) => {
  try {
    const proveedores = await Proveedor.find();
    res.json({ ok: true, data: proveedores });
  } catch (error) {
    res.status(400).json({ ok: false, mensaje: error.message });
  }
});

app.post("/api/proveedores", async (req, res) => {
  try {
    const nuevoProveedor = new Proveedor(req.body);
    const resultado = await nuevoProveedor.save();
    res.json({ ok: true, data: resultado, mensaje: "Proveedor creado" });
  } catch (error) {
    res.status(400).json({ ok: false, mensaje: error.message });
  }
});

app.put("/api/proveedores/:id", async (req, res) => {
  try {
    const proveedorActualizado = await Proveedor.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    if (!proveedorActualizado) return res.status(404).json({ ok: false, mensaje: "Proveedor no encontrado" });
    res.json({ ok: true, data: proveedorActualizado, mensaje: "Proveedor actualizado" });
  } catch (error) {
    res.status(400).json({ ok: false, mensaje: error.message });
  }
});

app.delete("/api/proveedores/:id", async (req, res) => {
  try {
    const proveedor = await Proveedor.findByIdAndDelete(req.params.id);
    if (!proveedor) return res.status(404).json({ ok: false, mensaje: "Proveedor no encontrado" });
    res.json({ ok: true, mensaje: "Proveedor eliminado" });
  } catch (error) {
    res.status(400).json({ ok: false, mensaje: error.message });
  }
});

// INICIAR SERVIDOR
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`🚀 Servidor en http://localhost:${PORT}`);
});