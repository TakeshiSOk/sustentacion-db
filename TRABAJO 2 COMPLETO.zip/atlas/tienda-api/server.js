const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();
app.use(express.json());
app.use(cors());

// ✅ CONEXIÓN CORREGIDA - sin opciones obsoletas
mongoose.connect("mongodb+srv://janergomez765_db_user:root@cluster0.papnyk8.mongodb.net/tienda_online")
  .then(() => console.log("✅ Conectado a MongoDB Atlas"))
  .catch(err => console.log("❌ Error de conexión:", err));

// Ruta de prueba
app.get("/", (req, res) => {
  res.send("API funcionando 🚀");
});

// Ruta health check
app.get("/api/health", (req, res) => {
  res.json({ ok: true, mensaje: "API funcionando" });
});

// Modelo Cliente
const clienteSchema = new mongoose.Schema({
  nombre: String,
  email: String,
  edad: Number,
  ciudad: String,
  telefono: String,
  direccion: String
}, { timestamps: true });

const Cliente = mongoose.model("Cliente", clienteSchema);

// CRUD Clientes
app.get("/api/clientes", async (req, res) => {
  try {
    const clientes = await Cliente.find();
    res.json({ ok: true, data: clientes });
  } catch (error) {
    res.status(400).json({ ok: false, mensaje: error.message });
  }
});

app.get("/api/clientes/:id", async (req, res) => {
  try {
    const cliente = await Cliente.findById(req.params.id);
    if (!cliente) {
      return res.status(404).json({ ok: false, mensaje: "Cliente no encontrado" });
    }
    res.json({ ok: true, data: cliente });
  } catch (error) {
    res.status(400).json({ ok: false, mensaje: error.message });
  }
});

app.post("/api/clientes", async (req, res) => {
  try {
    const nuevoCliente = new Cliente(req.body);
    const resultado = await nuevoCliente.save();
    res.json({ ok: true, data: resultado, mensaje: "Cliente creado" });
  } catch (error) {
    res.status(400).json({ ok: false, mensaje: error.message });
  }
});

app.put("/api/clientes/:id", async (req, res) => {
  try {
    const clienteActualizado = await Cliente.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    if (!clienteActualizado) {
      return res.status(404).json({ ok: false, mensaje: "Cliente no encontrado" });
    }
    res.json({ ok: true, data: clienteActualizado, mensaje: "Cliente actualizado" });
  } catch (error) {
    res.status(400).json({ ok: false, mensaje: error.message });
  }
});

app.delete("/api/clientes/:id", async (req, res) => {
  try {
    const cliente = await Cliente.findByIdAndDelete(req.params.id);
    if (!cliente) {
      return res.status(404).json({ ok: false, mensaje: "Cliente no encontrado" });
    }
    res.json({ ok: true, mensaje: "Cliente eliminado" });
  } catch (error) {
    res.status(400).json({ ok: false, mensaje: error.message });
  }
});

// Iniciar servidor
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
});