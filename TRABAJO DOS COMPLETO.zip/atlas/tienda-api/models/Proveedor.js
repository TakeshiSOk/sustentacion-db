const mongoose = require('mongoose');

const proveedorSchema = new mongoose.Schema({
  nombre: { type: String, required: true },
  contacto: String,
  email: String,
  telefono: String,
  ciudad: String,
  categorias_suministradas: [String]
}, { timestamps: true });

module.exports = mongoose.model('Proveedor', proveedorSchema);