const API_URL = 'http://localhost:3000/api';

// Probar conexión
async function ping() {
    const dot = document.getElementById('dot');
    const statusText = document.getElementById('status-text');
    
    try {
        const response = await fetch(`${API_URL}/health`);
        if (response.ok) {
            dot.className = 'status-dot on';
            statusText.textContent = 'Conectado ✅';
            mostrarRespuesta('Conexión exitosa con el servidor');
        } else {
            throw new Error();
        }
    } catch (error) {
        dot.className = 'status-dot off';
        statusText.textContent = 'Desconectado ❌';
        mostrarRespuesta('Error: No se pudo conectar al servidor', true);
    }
}

// Mostrar respuesta en el panel
function mostrarRespuesta(data, isError = false) {
    const responseDiv = document.getElementById('response');
    responseDiv.style.color = isError ? '#f44336' : '#4caf50';
    responseDiv.textContent = typeof data === 'object' ? JSON.stringify(data, null, 2) : data;
}

// Cargar todos los clientes
async function cargarClientes() {
    try {
        const response = await fetch(`${API_URL}/clientes`);
        const data = await response.json();
        
        if (data.ok) {
            mostrarClientes(data.data);
            mostrarRespuesta(data);
        } else {
            mostrarRespuesta(data.mensaje, true);
        }
    } catch (error) {
        mostrarRespuesta('Error al cargar clientes: ' + error.message, true);
    }
}

// Mostrar clientes en la lista
function mostrarClientes(clientes) {
    const container = document.getElementById('clientes-container');
    
    if (!clientes || clientes.length === 0) {
        container.innerHTML = '<p>No hay clientes registrados</p>';
        return;
    }
    
    container.innerHTML = clientes.map(cliente => `
        <div class="cliente-card" onclick="cargarClienteParaActualizar('${cliente._id}')">
            <div class="cliente-nombre">${cliente.nombre}</div>
            <div class="cliente-email">📧 ${cliente.email}</div>
            <div class="cliente-email">🎂 ${cliente.edad} años</div>
            <div class="cliente-email">📍 ${cliente.ciudad}</div>
            ${cliente.telefono ? `<div class="cliente-email">📱 ${cliente.telefono}</div>` : ''}
            <div class="cliente-id">ID: ${cliente._id}</div>
        </div>
    `).join('');
}

// Crear nuevo cliente
async function crearCliente() {
    const nombre = document.getElementById('nombre').value;
    const email = document.getElementById('email').value;
    const edad = document.getElementById('edad').value;
    const ciudad = document.getElementById('ciudad').value;
    const telefono = document.getElementById('telefono').value;
    const direccion = document.getElementById('direccion').value;
    
    if (!nombre || !email || !edad || !ciudad) {
        mostrarRespuesta('⚠️ Los campos nombre, email, edad y ciudad son obligatorios', true);
        return;
    }
    
    const cliente = { nombre, email, edad: parseInt(edad), ciudad, telefono, direccion };
    
    try {
        const response = await fetch(`${API_URL}/clientes`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(cliente)
        });
        
        const data = await response.json();
        
        if (data.ok) {
            mostrarRespuesta(data);
            cargarClientes();
            // Limpiar formulario
            document.getElementById('nombre').value = '';
            document.getElementById('email').value = '';
            document.getElementById('edad').value = '';
            document.getElementById('ciudad').value = '';
            document.getElementById('telefono').value = '';
            document.getElementById('direccion').value = '';
        } else {
            mostrarRespuesta(data.mensaje, true);
        }
    } catch (error) {
        mostrarRespuesta('Error al crear cliente: ' + error.message, true);
    }
}

// Cargar cliente para actualizar
function cargarClienteParaActualizar(id) {
    document.getElementById('update-id').value = id;
    mostrarRespuesta(`ID ${id} cargado para actualizar. Modifica los campos y presiona Actualizar.`);
}

// Actualizar cliente
async function actualizarCliente() {
    const id = document.getElementById('update-id').value;
    const nombre = document.getElementById('update-nombre').value;
    const email = document.getElementById('update-email').value;
    const edad = document.getElementById('update-edad').value;
    const ciudad = document.getElementById('update-ciudad').value;
    
    if (!id) {
        mostrarRespuesta('⚠️ Debes ingresar un ID de cliente', true);
        return;
    }
    
    const updates = {};
    if (nombre) updates.nombre = nombre;
    if (email) updates.email = email;
    if (edad) updates.edad = parseInt(edad);
    if (ciudad) updates.ciudad = ciudad;
    
    try {
        const response = await fetch(`${API_URL}/clientes/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updates)
        });
        
        const data = await response.json();
        
        if (data.ok) {
            mostrarRespuesta(data);
            cargarClientes();
            // Limpiar formulario
            document.getElementById('update-id').value = '';
            document.getElementById('update-nombre').value = '';
            document.getElementById('update-email').value = '';
            document.getElementById('update-edad').value = '';
            document.getElementById('update-ciudad').value = '';
        } else {
            mostrarRespuesta(data.mensaje, true);
        }
    } catch (error) {
        mostrarRespuesta('Error al actualizar cliente: ' + error.message, true);
    }
}

// Eliminar cliente
async function eliminarCliente() {
    const id = document.getElementById('delete-id').value;
    
    if (!id) {
        mostrarRespuesta('⚠️ Debes ingresar un ID de cliente', true);
        return;
    }
    
    if (!confirm('¿Estás seguro de eliminar este cliente? Esta acción no se puede deshacer.')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/clientes/${id}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (data.ok) {
            mostrarRespuesta(data);
            cargarClientes();
            document.getElementById('delete-id').value = '';
        } else {
            mostrarRespuesta(data.mensaje, true);
        }
    } catch (error) {
        mostrarRespuesta('Error al eliminar cliente: ' + error.message, true);
    }
}

// Cargar clientes al iniciar
cargarClientes();
ping();