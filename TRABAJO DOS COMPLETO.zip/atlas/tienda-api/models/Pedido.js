const mongoose = require('mongoose');

const pedidoSchema = new mongoose.Schema({
  cliente_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Cliente', required: true },
  productos: [{
    producto_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Producto', required: true },
    cantidad: { type: Number, required: true, min: 1 },
    nombre_producto: String,
    precio_unitario: Number
  }],
  total: { type: Number, required: true },
  estado: { type: String, enum: ['pendiente', 'procesando', 'enviado', 'entregado', 'cancelado'], default: 'pendiente' },
  direccion_entrega: String,
  nombre_cliente: String
}, { timestamps: true });

module.exports = mongoose.model('Pedido', pedidoSchema);