const API_URL = 'http://localhost:3000/api';

// Variables globales para pedidos
let productosDisponibles = [];
let clientesDisponibles = [];
let productosPedido = [];

// ============================================
// FUNCIONES GENERALES
// ============================================

async function ping() {
  const dot = document.getElementById('dot');
  const statusText = document.getElementById('status-text');
  
  try {
    const response = await fetch(`${API_URL}/health`);
    if (response.ok) {
      dot.className = 'status-dot on';
      statusText.textContent = 'Conectado ✅';
      mostrarRespuesta('✅ Conexión exitosa con el servidor');
    } else {
      throw new Error();
    }
  } catch (error) {
    dot.className = 'status-dot off';
    statusText.textContent = 'Desconectado ❌';
    mostrarRespuesta('❌ Error: No se pudo conectar al servidor', true);
  }
}

function mostrarRespuesta(data, isError = false) {
  const responseDiv = document.getElementById('response');
  responseDiv.style.color = isError ? '#ef4444' : '#10b981';
  responseDiv.textContent = typeof data === 'object' ? JSON.stringify(data, null, 2) : data;
}

function switchTab(tabName, btn) {
  document.querySelectorAll('.tab-content').forEach(tab => {
    tab.classList.remove('active');
  });
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.classList.remove('active');
  });
  document.getElementById(`tab-${tabName}`).classList.add('active');
  btn.classList.add('active');
  
  if (tabName === 'clientes') cargarClientes();
  if (tabName === 'productos') cargarProductos();
  if (tabName === 'pedidos') {
    cargarClientesSelect();
    cargarProductosSelect();
    cargarPedidos();
  }
  if (tabName === 'proveedores') cargarProveedores();
}

// ============================================
// CLIENTES
// ============================================

async function cargarClientes() {
  try {
    const response = await fetch(`${API_URL}/clientes`);
    const data = await response.json();
    if (data.ok) {
      mostrarClientes(data.data);
    }
  } catch (error) {
    mostrarRespuesta('Error al cargar clientes', true);
  }
}

function mostrarClientes(clientes) {
  const container = document.getElementById('lista-clientes');
  if (!clientes || clientes.length === 0) {
    container.innerHTML = '<div class="items-container"><p style="text-align:center; color:#9ca3af;">No hay clientes registrados</p></div>';
    return;
  }
  
  container.innerHTML = clientes.map(cliente => `
    <div class="item-card" onclick="cargarClienteParaActualizar('${cliente._id}')">
      <div class="item-nombre">👤 ${cliente.nombre}</div>
      <div class="item-detalle">📧 ${cliente.email} | 🎂 ${cliente.edad} años | 📍 ${cliente.ciudad}</div>
      <div class="item-id">ID: ${cliente._id}</div>
    </div>
  `).join('');
}

function cargarClienteParaActualizar(id) {
  document.getElementById('cli-update-id').value = id;
  mostrarRespuesta(`📋 ID ${id} cargado para actualizar`);
}

async function crearCliente() {
  const data = {
    nombre: document.getElementById('cli-nombre').value,
    email: document.getElementById('cli-email').value,
    edad: parseInt(document.getElementById('cli-edad').value),
    ciudad: document.getElementById('cli-ciudad').value,
    telefono: document.getElementById('cli-telefono').value,
    direccion: document.getElementById('cli-direccion').value
  };
  
  if (!data.nombre || !data.email || !data.edad || !data.ciudad) {
    mostrarRespuesta('⚠️ Nombre, email, edad y ciudad son obligatorios', true);
    return;
  }
  
  try {
    const response = await fetch(`${API_URL}/clientes`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    const result = await response.json();
    mostrarRespuesta(result);
    if (result.ok) {
      cargarClientes();
      document.getElementById('cli-nombre').value = '';
      document.getElementById('cli-email').value = '';
      document.getElementById('cli-edad').value = '';
      document.getElementById('cli-ciudad').value = '';
      document.getElementById('cli-telefono').value = '';
      document.getElementById('cli-direccion').value = '';
    }
  } catch (error) {
    mostrarRespuesta('Error al crear cliente', true);
  }
}

async function actualizarCliente() {
  const id = document.getElementById('cli-update-id').value;
  if (!id) {
    mostrarRespuesta('⚠️ Ingresa un ID', true);
    return;
  }
  
  const updates = {};
  const nombre = document.getElementById('cli-update-nombre').value;
  const email = document.getElementById('cli-update-email').value;
  const edad = document.getElementById('cli-update-edad').value;
  const ciudad = document.getElementById('cli-update-ciudad').value;
  
  if (nombre) updates.nombre = nombre;
  if (email) updates.email = email;
  if (edad) updates.edad = parseInt(edad);
  if (ciudad) updates.ciudad = ciudad;
  
  try {
    const response = await fetch(`${API_URL}/clientes/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates)
    });
    const result = await response.json();
    mostrarRespuesta(result);
    if (result.ok) {
      cargarClientes();
      document.getElementById('cli-update-id').value = '';
      document.getElementById('cli-update-nombre').value = '';
      document.getElementById('cli-update-email').value = '';
      document.getElementById('cli-update-edad').value = '';
      document.getElementById('cli-update-ciudad').value = '';
    }
  } catch (error) {
    mostrarRespuesta('Error al actualizar cliente', true);
  }
}

async function eliminarCliente() {
  const id = document.getElementById('cli-delete-id').value;
  if (!id) {
    mostrarRespuesta('⚠️ Ingresa un ID', true);
    return;
  }
  
  if (!confirm('¿Seguro que deseas eliminar este cliente?')) return;
  
  try {
    const response = await fetch(`${API_URL}/clientes/${id}`, {
      method: 'DELETE'
    });
    const result = await response.json();
    mostrarRespuesta(result);
    if (result.ok) {
      cargarClientes();
      document.getElementById('cli-delete-id').value = '';
    }
  } catch (error) {
    mostrarRespuesta('Error al eliminar cliente', true);
  }
}

// ============================================
// PRODUCTOS
// ============================================

async function cargarProductos() {
  try {
    const response = await fetch(`${API_URL}/productos`);
    const data = await response.json();
    if (data.ok) {
      productosDisponibles = data.data;
      mostrarProductos(productosDisponibles);
    }
  } catch (error) {
    mostrarRespuesta('Error al cargar productos', true);
  }
}

function mostrarProductos(productos) {
  const container = document.getElementById('lista-productos');
  if (!productos || productos.length === 0) {
    container.innerHTML = '<div class="items-container"><p style="text-align:center; color:#9ca3af;">No hay productos registrados</p></div>';
    return;
  }
  
  container.innerHTML = productos.map(p => `
    <div class="item-card" onclick="cargarProductoParaActualizar('${p._id}')">
      <div class="item-nombre">📦 ${p.nombre}</div>
      <div class="item-detalle">📂 ${p.categoria} | <span class="item-precio">💰 $${p.precio.toLocaleString()}</span> | <span class="item-stock">📦 Stock: ${p.stock}</span></div>
      <div class="item-id">ID: ${p._id}</div>
    </div>
  `).join('');
}

function cargarProductoParaActualizar(id) {
  document.getElementById('pro-update-id').value = id;
  mostrarRespuesta(`📋 ID ${id} cargado para actualizar`);
}

async function crearProducto() {
  const data = {
    nombre: document.getElementById('pro-nombre').value,
    categoria: document.getElementById('pro-categoria').value,
    precio: parseFloat(document.getElementById('pro-precio').value),
    stock: parseInt(document.getElementById('pro-stock').value),
    marca: document.getElementById('pro-marca').value,
    descripcion: document.getElementById('pro-descripcion').value
  };
  
  if (!data.nombre || !data.categoria || !data.precio) {
    mostrarRespuesta('⚠️ Nombre, categoría y precio son obligatorios', true);
    return;
  }
  
  try {
    const response = await fetch(`${API_URL}/productos`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    const result = await response.json();
    mostrarRespuesta(result);
    if (result.ok) {
      cargarProductos();
      document.getElementById('pro-nombre').value = '';
      document.getElementById('pro-categoria').value = '';
      document.getElementById('pro-precio').value = '';
      document.getElementById('pro-stock').value = '';
      document.getElementById('pro-marca').value = '';
      document.getElementById('pro-descripcion').value = '';
    }
  } catch (error) {
    mostrarRespuesta('Error al crear producto', true);
  }
}

async function actualizarProducto() {
  const id = document.getElementById('pro-update-id').value;
  if (!id) {
    mostrarRespuesta('⚠️ Ingresa un ID', true);
    return;
  }
  
  const updates = {};
  const nombre = document.getElementById('pro-update-nombre').value;
  const precio = document.getElementById('pro-update-precio').value;
  const stock = document.getElementById('pro-update-stock').value;
  
  if (nombre) updates.nombre = nombre;
  if (precio) updates.precio = parseFloat(precio);
  if (stock) updates.stock = parseInt(stock);
  
  try {
    const response = await fetch(`${API_URL}/productos/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates)
    });
    const result = await response.json();
    mostrarRespuesta(result);
    if (result.ok) {
      cargarProductos();
      document.getElementById('pro-update-id').value = '';
      document.getElementById('pro-update-nombre').value = '';
      document.getElementById('pro-update-precio').value = '';
      document.getElementById('pro-update-stock').value = '';
    }
  } catch (error) {
    mostrarRespuesta('Error al actualizar producto', true);
  }
}

async function eliminarProducto() {
  const id = document.getElementById('pro-delete-id').value;
  if (!id) {
    mostrarRespuesta('⚠️ Ingresa un ID', true);
    return;
  }
  
  if (!confirm('¿Seguro que deseas eliminar este producto?')) return;
  
  try {
    const response = await fetch(`${API_URL}/productos/${id}`, {
      method: 'DELETE'
    });
    const result = await response.json();
    mostrarRespuesta(result);
    if (result.ok) {
      cargarProductos();
      document.getElementById('pro-delete-id').value = '';
    }
  } catch (error) {
    mostrarRespuesta('Error al eliminar producto', true);
  }
}

// ============================================
// PEDIDOS CON CÁLCULO AUTOMÁTICO
// ============================================

async function cargarClientesSelect() {
  try {
    const response = await fetch(`${API_URL}/clientes`);
    const data = await response.json();
    if (data.ok) {
      clientesDisponibles = data.data;
      const select = document.getElementById('ped-cliente-id');
      select.innerHTML = '<option value="">Seleccionar cliente</option>' + 
        clientesDisponibles.map(c => `<option value="${c._id}">${c.nombre}</option>`).join('');
    }
  } catch (error) {
    console.error('Error cargando clientes', error);
  }
}

async function cargarProductosSelect() {
  try {
    const response = await fetch(`${API_URL}/productos`);
    const data = await response.json();
    if (data.ok) {
      productosDisponibles = data.data;
      actualizarSelectsProductos();
    }
  } catch (error) {
    console.error('Error cargando productos', error);
  }
}

function actualizarSelectsProductos() {
  const selects = document.querySelectorAll('.ped-producto-select');
  selects.forEach(select => {
    const currentValue = select.value;
    select.innerHTML = '<option value="">Seleccionar producto</option>' + 
      productosDisponibles.map(p => `<option value="${p._id}" data-precio="${p.precio}">${p.nombre} - $${p.precio.toLocaleString()}</option>`).join('');
    if (currentValue) select.value = currentValue;
  });
  calcularTotalPedido();
}

function agregarProductoPedido() {
  const container = document.getElementById('productos-pedido');
  const nuevoItem = document.createElement('div');
  nuevoItem.className = 'producto-item';
  nuevoItem.innerHTML = `
    <select class="ped-producto-select" style="width: 60%;" onchange="calcularTotalPedido()">
      <option value="">Seleccionar producto</option>
      ${productosDisponibles.map(p => `<option value="${p._id}" data-precio="${p.precio}">${p.nombre} - $${p.precio.toLocaleString()}</option>`).join('')}
    </select>
    <input type="number" class="ped-cantidad" placeholder="Cantidad" min="1" value="1" style="width: 35%;" onchange="calcularTotalPedido()">
    <button onclick="this.parentElement.remove(); calcularTotalPedido();" style="background:#ef4444; color:white; border:none; border-radius:8px; width:30px; cursor:pointer;">✕</button>
  `;
  container.appendChild(nuevoItem);
  calcularTotalPedido();
}

function calcularTotalPedido() {
  let total = 0;
  const items = document.querySelectorAll('.producto-item');
  
  items.forEach(item => {
    const select = item.querySelector('.ped-producto-select');
    const cantidad = parseInt(item.querySelector('.ped-cantidad').value) || 0;
    
    if (select && select.value) {
      const selectedOption = select.options[select.selectedIndex];
      const precio = parseFloat(selectedOption?.dataset.precio) || 0;
      total += precio * cantidad;
    }
  });
  
  const totalDiv = document.getElementById('pedido-total');
  if (totalDiv) {
    totalDiv.innerHTML = `💰 Total: $${total.toLocaleString()}`;
  }
}

async function crearPedido() {
  const cliente_id = document.getElementById('ped-cliente-id').value;
  const direccion_entrega = document.getElementById('ped-direccion').value;
  
  if (!cliente_id) {
    mostrarRespuesta('⚠️ Selecciona un cliente', true);
    return;
  }
  
  const productos = [];
  const items = document.querySelectorAll('.producto-item');
  
  for (const item of items) {
    const producto_id = item.querySelector('.ped-producto-select').value;
    const cantidad = parseInt(item.querySelector('.ped-cantidad').value);
    
    if (producto_id && cantidad > 0) {
      productos.push({ producto_id, cantidad });
    }
  }
  
  if (productos.length === 0) {
    mostrarRespuesta('⚠️ Agrega al menos un producto', true);
    return;
  }
  
  try {
    const response = await fetch(`${API_URL}/pedidos`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ cliente_id, productos, direccion_entrega })
    });
    const result = await response.json();
    mostrarRespuesta(result);
    
    if (result.ok) {
      cargarPedidos();
      cargarProductosSelect();
      // Limpiar formulario
      document.getElementById('ped-cliente-id').value = '';
      document.getElementById('ped-direccion').value = '';
      document.getElementById('productos-pedido').innerHTML = `
        <div class="producto-item">
          <select class="ped-producto-select" style="width: 60%;" onchange="calcularTotalPedido()">
            <option value="">Seleccionar producto</option>
          </select>
          <input type="number" class="ped-cantidad" placeholder="Cantidad" min="1" value="1" style="width: 35%;" onchange="calcularTotalPedido()">
          <button onclick="this.parentElement.remove(); calcularTotalPedido();" style="background:#ef4444; color:white; border:none; border-radius:8px; width:30px; cursor:pointer;">✕</button>
        </div>
      `;
      actualizarSelectsProductos();
    }
  } catch (error) {
    mostrarRespuesta('Error al crear pedido: ' + error.message, true);
  }
}

async function cargarPedidos() {
  try {
    const response = await fetch(`${API_URL}/pedidos`);
    const data = await response.json();
    if (data.ok) {
      mostrarPedidos(data.data);
    }
  } catch (error) {
    mostrarRespuesta('Error al cargar pedidos', true);
  }
}

function mostrarPedidos(pedidos) {
  const container = document.getElementById('lista-pedidos');
  if (!pedidos || pedidos.length === 0) {
    container.innerHTML = '<div class="items-container"><p style="text-align:center; color:#9ca3af;">No hay pedidos registrados</p></div>';
    return;
  }
  
  const estadoClass = {
    'pendiente': 'estado-pendiente',
    'procesando': 'estado-procesando',
    'enviado': 'estado-enviado',
    'entregado': 'estado-entregado',
    'cancelado': 'estado-cancelado'
  };
  
  container.innerHTML = pedidos.map(p => `
    <div class="item-card">
      <div class="item-nombre">🧑 ${p.nombre_cliente || 'Cliente'}</div>
      <div class="item-detalle">📦 ${(p.productos || []).map(pr => `${pr.nombre_producto} x${pr.cantidad}`).join(', ') || 'Sin productos'}</div>
      <div class="item-detalle"><span class="item-precio">💰 $${(p.total || 0).toLocaleString()}</span> | <span class="item-estado ${estadoClass[p.estado]}">${p.estado}</span></div>
      <div class="item-id">ID: ${p._id}</div>
    </div>
  `).join('');
}

async function actualizarPedido() {
  const id = document.getElementById('ped-update-id').value;
  const estado = document.getElementById('ped-estado').value;
  
  if (!id) {
    mostrarRespuesta('⚠️ Ingresa el ID del pedido', true);
    return;
  }
  
  try {
    const response = await fetch(`${API_URL}/pedidos/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ estado })
    });
    const result = await response.json();
    mostrarRespuesta(result);
    if (result.ok) {
      cargarPedidos();
      document.getElementById('ped-update-id').value = '';
    }
  } catch (error) {
    mostrarRespuesta('Error al actualizar pedido', true);
  }
}

async function eliminarPedido() {
  const id = document.getElementById('ped-delete-id').value;
  if (!id) {
    mostrarRespuesta('⚠️ Ingresa el ID del pedido', true);
    return;
  }
  
  if (!confirm('¿Seguro que deseas eliminar este pedido?')) return;
  
  try {
    const response = await fetch(`${API_URL}/pedidos/${id}`, {
      method: 'DELETE'
    });
    const result = await response.json();
    mostrarRespuesta(result);
    if (result.ok) {
      cargarPedidos();
      document.getElementById('ped-delete-id').value = '';
    }
  } catch (error) {
    mostrarRespuesta('Error al eliminar pedido', true);
  }
}

// ============================================
// PROVEEDORES
// ============================================

async function cargarProveedores() {
  try {
    const response = await fetch(`${API_URL}/proveedores`);
    const data = await response.json();
    if (data.ok) {
      mostrarProveedores(data.data);
    }
  } catch (error) {
    mostrarRespuesta('Error al cargar proveedores', true);
  }
}

function mostrarProveedores(proveedores) {
  const container = document.getElementById('lista-proveedores');
  if (!proveedores || proveedores.length === 0) {
    container.innerHTML = '<div class="items-container"><p style="text-align:center; color:#9ca3af;">No hay proveedores registrados</p></div>';
    return;
  }
  
  container.innerHTML = proveedores.map(p => `
    <div class="item-card" onclick="cargarProveedorParaActualizar('${p._id}')">
      <div class="item-nombre">🏭 ${p.nombre}</div>
      <div class="item-detalle">📧 ${p.email || 'Sin email'} | 📞 ${p.telefono || 'Sin teléfono'} | 📍 ${p.ciudad || 'Sin ciudad'}</div>
      <div class="item-detalle">📦 ${(p.categorias_suministradas || []).join(', ') || 'Sin categorías'}</div>
      <div class="item-id">ID: ${p._id}</div>
    </div>
  `).join('');
}

function cargarProveedorParaActualizar(id) {
  document.getElementById('prov-update-id').value = id;
  mostrarRespuesta(`📋 ID ${id} cargado para actualizar`);
}

async function crearProveedor() {
  const categorias = document.getElementById('prov-categorias').value
    .split(',')
    .map(c => c.trim())
    .filter(c => c);
  
  const data = {
    nombre: document.getElementById('prov-nombre').value,
    contacto: document.getElementById('prov-contacto').value,
    email: document.getElementById('prov-email').value,
    telefono: document.getElementById('prov-telefono').value,
    ciudad: document.getElementById('prov-ciudad').value,
    categorias_suministradas: categorias
  };
  
  if (!data.nombre) {
    mostrarRespuesta('⚠️ El nombre del proveedor es obligatorio', true);
    return;
  }
  
  try {
    const response = await fetch(`${API_URL}/proveedores`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    const result = await response.json();
    mostrarRespuesta(result);
    if (result.ok) {
      cargarProveedores();
      document.getElementById('prov-nombre').value = '';
      document.getElementById('prov-contacto').value = '';
      document.getElementById('prov-email').value = '';
      document.getElementById('prov-telefono').value = '';
      document.getElementById('prov-ciudad').value = '';
      document.getElementById('prov-categorias').value = '';
    }
  } catch (error) {
    mostrarRespuesta('Error al crear proveedor', true);
  }
}

async function actualizarProveedor() {
  const id = document.getElementById('prov-update-id').value;
  if (!id) {
    mostrarRespuesta('⚠️ Ingresa un ID', true);
    return;
  }
  
  const updates = {};
  const nombre = document.getElementById('prov-update-nombre').value;
  const email = document.getElementById('prov-update-email').value;
  const telefono = document.getElementById('prov-update-telefono').value;
  
  if (nombre) updates.nombre = nombre;
  if (email) updates.email = email;
  if (telefono) updates.telefono = telefono;
  
  try {
    const response = await fetch(`${API_URL}/proveedores/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates)
    });
    const result = await response.json();
    mostrarRespuesta(result);
    if (result.ok) {
      cargarProveedores();
      document.getElementById('prov-update-id').value = '';
      document.getElementById('prov-update-nombre').value = '';
      document.getElementById('prov-update-email').value = '';
      document.getElementById('prov-update-telefono').value = '';
    }
  } catch (error) {
    mostrarRespuesta('Error al actualizar proveedor', true);
  }
}

async function eliminarProveedor() {
  const id = document.getElementById('prov-delete-id').value;
  if (!id) {
    mostrarRespuesta('⚠️ Ingresa un ID', true);
    return;
  }
  
  if (!confirm('¿Seguro que deseas eliminar este proveedor?')) return;
  
  try {
    const response = await fetch(`${API_URL}/proveedores/${id}`, {
      method: 'DELETE'
    });
    const result = await response.json();
    mostrarRespuesta(result);
    if (result.ok) {
      cargarProveedores();
      document.getElementById('prov-delete-id').value = '';
    }
  } catch (error) {
    mostrarRespuesta('Error al eliminar proveedor', true);
  }
}

// ============================================
// INICIALIZAR
// ============================================

ping();
cargarClientes();
cargarProductos();
cargarProveedores();